# SmartCRM — Java JDBC Backend Startup Script
# Run this script from the server/ folder: .\start.ps1
# KTU CS OOP 2024 Scheme

Write-Host ""
Write-Host "Starting SmartCRM Java JDBC Backend..." -ForegroundColor Cyan
Write-Host ""

$JAVA  = "C:\Users\MYCARE\jdk21\bin\java.exe"
$JAR   = "lib\sqlite-jdbc.jar"
$MAIN  = "com.smartcrm.server.CrmServer"

& $JAVA -cp "$JAR;out" $MAIN
